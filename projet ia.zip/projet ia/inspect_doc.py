import re

with open('maishapay_doc.html', 'r', encoding='utf-8') as f:
    content = f.read()

# Extract title
title_m = re.search(r'<title>(.*?)</title>', content, re.IGNORECASE)
print("Title:", title_m.group(1) if title_m else "None")

# Extract all links
links = re.findall(r'<a\s+[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', content, re.DOTALL | re.IGNORECASE)
print("\n--- Links found ---")
for href, txt in links:
    clean_txt = re.sub(r'<[^>]+>', '', txt).strip()
    if clean_txt or 'http' in href:
        print(f"{href} -> {clean_txt}")

# Remove tags and dump clean text summary
text_clean = re.sub(r'<script.*?</script>', '', content, flags=re.DOTALL | re.IGNORECASE)
text_clean = re.sub(r'<style.*?</style>', '', text_clean, flags=re.DOTALL | re.IGNORECASE)
text_clean = re.sub(r'<[^>]+>', ' ', text_clean)
lines = [l.strip() for l in text_clean.splitlines() if l.strip()]

with open('maishapay_doc_clean.txt', 'w', encoding='utf-8') as out:
    out.write('\n'.join(lines))

print(f"\nWrote {len(lines)} lines of text to maishapay_doc_clean.txt")
