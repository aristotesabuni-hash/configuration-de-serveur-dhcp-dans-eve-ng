from django.contrib import admin
from aeroassist.models import (
    ProcedureCategory,
    ProcedureDocument,
    FAQItem,
    NetworkVlan,
    NetworkDevice,
    NetworkIncident,
    NetworkDiagnosticLog,
    ChatMessage,
    ScenarioRun,
    SystemSetting
)

@admin.register(ProcedureCategory)
class ProcedureCategoryAdmin(admin.ModelAdmin):
    list_display = ('code', 'name', 'icon', 'display_order')
    ordering = ('display_order',)

@admin.register(ProcedureDocument)
class ProcedureDocumentAdmin(admin.ModelAdmin):
    list_display = ('title', 'category', 'version', 'source', 'validator', 'validation_date', 'is_active')
    list_filter = ('category', 'is_active', 'validation_date')
    search_fields = ('title', 'content', 'validator', 'source')

@admin.register(FAQItem)
class FAQItemAdmin(admin.ModelAdmin):
    list_display = ('question_fr', 'category', 'is_verified', 'flagged_for_review', 'created_at')
    list_filter = ('category', 'is_verified', 'flagged_for_review')
    search_fields = ('question_fr', 'answer_fr', 'question_en', 'question_sw', 'keywords')

@admin.register(NetworkVlan)
class NetworkVlanAdmin(admin.ModelAdmin):
    list_display = ('vlan_id', 'name', 'subnet', 'gateway', 'color')
    ordering = ('vlan_id',)

@admin.register(NetworkDevice)
class NetworkDeviceAdmin(admin.ModelAdmin):
    list_display = ('hostname', 'name', 'ip_address', 'vlan', 'device_type', 'status', 'latency_ms', 'is_simulated_down')
    list_filter = ('vlan', 'device_type', 'status', 'is_simulated_down')
    search_fields = ('hostname', 'name', 'ip_address')

@admin.register(NetworkIncident)
class NetworkIncidentAdmin(admin.ModelAdmin):
    list_display = ('title', 'device', 'severity', 'status', 'ping_result', 'tcp_result', 'created_at')
    list_filter = ('severity', 'status', 'created_at')
    search_fields = ('title', 'device__hostname', 'ai_probable_cause')

@admin.register(NetworkDiagnosticLog)
class NetworkDiagnosticLogAdmin(admin.ModelAdmin):
    list_display = ('created_at', 'tool_type', 'target', 'port', 'status', 'rtt_ms', 'is_authorized', 'triggered_by')
    list_filter = ('tool_type', 'status', 'is_authorized')
    search_fields = ('target', 'output_summary', 'raw_output')

@admin.register(ChatMessage)
class ChatMessageAdmin(admin.ModelAdmin):
    list_display = ('created_at', 'user_role', 'language', 'user_text_short', 'is_out_of_scope', 'is_injection_attempt')
    list_filter = ('language', 'user_role', 'is_out_of_scope', 'is_injection_attempt')
    search_fields = ('user_text', 'bot_response')

    def user_text_short(self, obj):
        return obj.user_text[:50]
    user_text_short.short_description = "Message passager"

@admin.register(ScenarioRun)
class ScenarioRunAdmin(admin.ModelAdmin):
    list_display = ('scenario_number', 'title', 'passed', 'last_run_at')
    ordering = ('scenario_number',)

@admin.register(SystemSetting)
class SystemSettingAdmin(admin.ModelAdmin):
    list_display = ('key', 'value', 'description')
