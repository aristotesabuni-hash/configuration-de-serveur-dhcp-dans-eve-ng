from django.urls import path
from aeroassist import views

urlpatterns = [
    # Pages principales
    path('', views.dashboard_view, name='dashboard'),
    path('assistant/', views.passenger_assistant_view, name='passenger_assistant'),
    path('travel-steps/', views.travel_steps_view, name='travel_steps'),
    path('faq/', views.procedures_faq_view, name='procedures_faq'),
    path('supervision/', views.network_supervision_view, name='network_supervision'),
    path('alerts/<int:alert_id>/', views.alert_detail_view, name='alert_detail'),
    path('reports/', views.reports_view, name='reports'),
    path('reports/export/csv/', views.export_reports_csv, name='export_reports_csv'),
    path('scenarios/', views.scenarios_test_bench_view, name='scenarios_bench'),
    path('settings/', views.administration_settings_view, name='settings'),
    path('switch-role/<str:role>/', views.switch_role_view, name='switch_role'),

    # Endpoints API Ajax
    path('api/chat/', views.api_chat, name='api_chat'),
    path('api/tool/run/', views.api_run_tool, name='api_run_tool'),
    path('api/simulate/toggle/', views.api_toggle_device_failure, name='api_simulate_toggle'),
    path('api/incidents/<int:incident_id>/action/', views.api_incident_action, name='api_incident_action'),
    path('api/scenarios/run/<int:scenario_num>/', views.api_run_scenario, name='api_run_scenario'),
    path('api/settings/openrouter/save/', views.api_save_openrouter_settings, name='api_save_openrouter_settings'),
    path('api/settings/openrouter/test/', views.api_test_openrouter, name='api_test_openrouter'),
]

