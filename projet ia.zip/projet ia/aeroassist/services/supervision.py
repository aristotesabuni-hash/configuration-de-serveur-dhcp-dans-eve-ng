import ipaddress
import socket
import time
import random
from datetime import datetime
from django.utils import timezone
from aeroassist.models import NetworkDevice, NetworkIncident, NetworkDiagnosticLog, SystemSetting

DEFAULT_ALLOWED_SUBNETS = [
    "192.168.10.0/24",  # Admin
    "192.168.20.0/24",  # Passagers
    "192.168.30.0/24",  # Serveurs lab
    "192.168.40.0/24",  # Supervision
    "192.168.50.0/24",  # Affichage
    "192.168.60.0/24",  # Invités
    "127.0.0.1/32",     # Localhost
]

def is_ip_whitelisted(ip_str):
    """
    Vérifie si une adresse IP appartient aux sous-réseaux autorisés du laboratoire EVE-NG.
    Règle de sécurité : Seules les adresses du laboratoire sont autorisées.
    """
    try:
        raw_setting = SystemSetting.get_value("whitelist_subnets", "")
        if raw_setting:
            subnets = [s.strip() for s in raw_setting.split(",") if s.strip()]
        else:
            subnets = DEFAULT_ALLOWED_SUBNETS
        
        target_ip = ipaddress.ip_address(ip_str.strip())
        for subnet_str in subnets:
            net = ipaddress.ip_network(subnet_str, strict=False)
            if target_ip in net:
                return True, "IP autorisée dans le périmètre du laboratoire EVE-NG"
        return False, f"IP {ip_str} hors liste blanche du laboratoire EVE-NG (Sécurité active)"
    except Exception as e:
        return False, f"Format d'adresse IP invalide : {str(e)}"

def run_ping_checker(target_ip, count=3, triggered_by="Technicien IT"):
    """
    Outil Ping Checker :
    Entrée : IP autorisée du lab
    Sortie : Réponse, délai, perte
    """
    allowed, reason = is_ip_whitelisted(target_ip)
    if not allowed:
        log = NetworkDiagnosticLog.objects.create(
            tool_type='PING',
            target=target_ip,
            status='BLOCKED',
            output_summary=f"Blocage de sécurité : {reason}",
            raw_output=f"Security Alert: Ping request to {target_ip} rejected. Destination outside approved EVE-NG testbed scope.",
            is_authorized=False,
            triggered_by=triggered_by
        )
        return {
            'success': False,
            'blocked': True,
            'summary': reason,
            'latency_ms': None,
            'packet_loss': 100.0,
            'raw_output': log.raw_output,
            'log_id': log.id
        }

    # Recherche si l'appareil est dans notre inventaire virtuel
    device = NetworkDevice.objects.filter(ip_address=target_ip).first()
    
    # Vérification si l'équipement a une simulation de panne
    is_down = False
    if device:
        override = device.get_service_override_dict()
        if device.is_simulated_down or override.get('ping') is False or device.status == 'offline':
            is_down = True
    
    if is_down:
        latency = None
        loss = 100.0
        status_code = 'FAILURE'
        summary = f"Ping {target_ip} : ÉCHEC (Délai d'attente dépassé, 100% perte)"
        raw = f"PING {target_ip} (56 data bytes):\nRequest timeout for icmp_seq 0\nRequest timeout for icmp_seq 1\nRequest timeout for icmp_seq 2\n--- {target_ip} ping statistics ---\n3 packets transmitted, 0 packets received, 100.0% packet loss"
    else:
        latency = round(random.uniform(0.8, 4.5), 2)
        loss = 0.0
        status_code = 'SUCCESS'
        summary = f"Ping {target_ip} : RÉUSSI (RTT: {latency} ms, 0% perte)"
        raw = f"PING {target_ip} (56 data bytes):\n64 bytes from {target_ip}: icmp_seq=0 ttl=64 time={latency} ms\n64 bytes from {target_ip}: icmp_seq=1 ttl=64 time={round(latency+0.2, 2)} ms\n64 bytes from {target_ip}: icmp_seq=2 ttl=64 time={round(latency-0.1, 2)} ms\n--- {target_ip} ping statistics ---\n3 packets transmitted, 3 packets received, 0.0% packet loss\nrtt min/avg/max = {round(latency-0.1, 2)}/{latency}/{round(latency+0.2, 2)} ms"

    log = NetworkDiagnosticLog.objects.create(
        tool_type='PING',
        target=target_ip,
        status=status_code,
        output_summary=summary,
        raw_output=raw,
        rtt_ms=latency,
        is_authorized=True,
        triggered_by=triggered_by
    )

    if device:
        device.latency_ms = latency if latency else 999.0
        device.packet_loss_percent = loss
        device.last_checked = timezone.now()
        device.save(update_fields=['latency_ms', 'packet_loss_percent', 'last_checked'])

    return {
        'success': not is_down,
        'blocked': False,
        'summary': summary,
        'latency_ms': latency,
        'packet_loss': loss,
        'raw_output': raw,
        'log_id': log.id
    }

def run_tcp_checker(target_ip, port=80, timeout=2.0, triggered_by="Technicien IT"):
    """
    Outil TCP Checker :
    Entrée : IP + port autorisé
    Sortie : Ouvert, fermé, délai dépassé
    """
    allowed, reason = is_ip_whitelisted(target_ip)
    if not allowed:
        log = NetworkDiagnosticLog.objects.create(
            tool_type='TCP',
            target=target_ip,
            port=port,
            status='BLOCKED',
            output_summary=f"Blocage de sécurité : {reason}",
            raw_output=f"Security Alert: TCP connection to {target_ip}:{port} blocked. Out of authorized scope.",
            is_authorized=False,
            triggered_by=triggered_by
        )
        return {
            'success': False,
            'blocked': True,
            'state': 'BLOCKED',
            'summary': reason,
            'raw_output': log.raw_output,
            'log_id': log.id
        }

    device = NetworkDevice.objects.filter(ip_address=target_ip).first()
    is_closed = False
    
    if device:
        override = device.get_service_override_dict()
        open_ports = [int(p.strip()) for p in device.ports_open.split(',') if p.strip().isdigit()]
        if device.is_simulated_down or override.get(f'port_{port}') is False or override.get('tcp') is False:
            is_closed = True
        elif port not in open_ports:
            is_closed = True
    else:
        # Si inconnu mais dans la plage, port fermé par défaut
        is_closed = True

    start_t = time.time()
    elapsed_ms = round(random.uniform(1.2, 5.0), 2)

    if is_closed:
        status_code = 'FAILURE'
        state = 'FERMÉ'
        summary = f"TCP {target_ip}:{port} : Port FERMÉ / Connection refused"
        raw = f"Connecting to {target_ip} on port {port}...\n[ERR] Connection refused by remote host (RST/ACK received)\nState: CLOSED / INACTIVE"
    else:
        status_code = 'SUCCESS'
        state = 'OUVERT'
        summary = f"TCP {target_ip}:{port} : Port OUVERT (Handshake SYN/ACK réussi en {elapsed_ms} ms)"
        raw = f"Connecting to {target_ip} on port {port}...\n[OK] TCP SYN sent, SYN/ACK received in {elapsed_ms}ms\n[OK] Connection established (ESTABLISHED)\nState: OPEN / LISTENING"

    log = NetworkDiagnosticLog.objects.create(
        tool_type='TCP',
        target=target_ip,
        port=port,
        status=status_code,
        output_summary=summary,
        raw_output=raw,
        rtt_ms=elapsed_ms,
        is_authorized=True,
        triggered_by=triggered_by
    )

    return {
        'success': not is_closed,
        'blocked': False,
        'state': state,
        'summary': summary,
        'raw_output': raw,
        'log_id': log.id
    }

def run_dns_checker(domain_name="web.lab.goma.aero", triggered_by="Technicien IT"):
    """
    Outil DNS Checker :
    Entrée : Nom du domaine de lab
    Sortie : Adresse résolue ou erreur
    """
    dns_server = NetworkDevice.objects.filter(hostname="DNS-LAB").first()
    is_dns_broken = False
    if dns_server:
        override = dns_server.get_service_override_dict()
        if dns_server.is_simulated_down or override.get('dns') is False or dns_server.status == 'offline':
            is_dns_broken = True

    # Tables de correspondance lab
    lab_records = {
        "web.lab.goma.aero": "192.168.30.10",
        "dns.lab.goma.aero": "192.168.30.11",
        "kiosk.lab.goma.aero": "192.168.20.20",
        "monitor.lab.goma.aero": "192.168.40.10",
        "fids.lab.goma.aero": "192.168.50.10",
        "router.lab.goma.aero": "192.168.30.1",
    }

    if is_dns_broken:
        status_code = 'FAILURE'
        summary = f"Résolution DNS '{domain_name}' : ÉCHEC (Serveur DNS-LAB 192.168.30.11 ne répond pas)"
        raw = f"; <<>> DiG 9.18.1-1 ubuntu <<>> @192.168.30.11 {domain_name}\n;; connection timed out; no servers could be reached\n;; Server error: NXDOMAIN or SERVFAIL"
        resolved_ip = None
    elif domain_name.lower() in lab_records:
        resolved_ip = lab_records[domain_name.lower()]
        status_code = 'SUCCESS'
        summary = f"Résolution DNS '{domain_name}' -> {resolved_ip} (OK)"
        raw = f"; <<>> DiG 9.18.1-1 ubuntu <<>> @192.168.30.11 {domain_name}\n;; Got answer:\n;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 48192\n;; QUESTION SECTION:\n;{domain_name}. IN A\n\n;; ANSWER SECTION:\n{domain_name}. 3600 IN A {resolved_ip}\n\n;; Query time: 2 msec\n;; SERVER: 192.168.30.11#53(192.168.30.11)"
    else:
        status_code = 'FAILURE'
        summary = f"Résolution DNS '{domain_name}' : ÉCHEC (Domaine inconnu dans la zone locale de lab)"
        raw = f"; <<>> DiG 9.18.1-1 ubuntu <<>> {domain_name}\n;; status: NXDOMAIN (Host not found in zone lab.goma.aero)"
        resolved_ip = None

    log = NetworkDiagnosticLog.objects.create(
        tool_type='DNS',
        target=domain_name,
        status=status_code,
        output_summary=summary,
        raw_output=raw,
        is_authorized=True,
        triggered_by=triggered_by
    )

    return {
        'success': (status_code == 'SUCCESS'),
        'blocked': False,
        'resolved_ip': resolved_ip,
        'summary': summary,
        'raw_output': raw,
        'log_id': log.id
    }

def run_http_checker(url="http://192.168.30.10", triggered_by="Technicien IT"):
    """
    Outil HTTP Checker :
    Entrée : URL locale autorisée
    Sortie : Code HTTP, délai, erreur
    """
    # Extraction de l'hôte
    clean_host = url.replace("http://", "").replace("https://", "").split("/")[0].split(":")[0]
    
    # Vérification liste blanche
    if clean_host.replace(".", "").isdigit():
        allowed, reason = is_ip_whitelisted(clean_host)
        if not allowed:
            log = NetworkDiagnosticLog.objects.create(
                tool_type='HTTP',
                target=url,
                status='BLOCKED',
                output_summary=f"Blocage de sécurité : {reason}",
                raw_output=f"Security Alert: HTTP target {url} outside of approved EVE-NG testbed IP whitelist.",
                is_authorized=False,
                triggered_by=triggered_by
            )
            return {'success': False, 'blocked': True, 'summary': reason, 'raw_output': log.raw_output, 'log_id': log.id}

    # Vérification du serveur WEB-LAB
    web_server = NetworkDevice.objects.filter(ip_address="192.168.30.10").first()
    is_down = False
    if web_server:
        override = web_server.get_service_override_dict()
        if web_server.is_simulated_down or override.get('http') is False or web_server.status == 'offline':
            is_down = True

    if is_down:
        status_code = 'FAILURE'
        http_code = 503
        summary = f"HTTP GET {url} : ÉCHEC (503 Service Unavailable / Connection Refused)"
        raw = f"GET {url}\nHTTP/1.1 503 Service Unavailable\nConnection: close\nContent-Type: text/html\n\n<html><body><h1>503 Service Unavailable</h1><p>The target server daemon is stopped or unreachable.</p></body></html>"
    else:
        status_code = 'SUCCESS'
        http_code = 200
        summary = f"HTTP GET {url} : SUCCÈS (Code 200 OK, 14ms)"
        raw = f"GET {url}\nHTTP/1.1 200 OK\nServer: Apache/2.4.52 (Ubuntu-Lab)\nContent-Type: text/html; charset=UTF-8\nContent-Length: 1420\nDate: {datetime.now().strftime('%a, %d %b %Y %H:%M:%S GMT')}\n\n<!DOCTYPE html><html><head><title>Aéroport Goma - Portail Démo</title></head><body><h1>Bienvenue sur le portail d'information passager</h1></body></html>"

    log = NetworkDiagnosticLog.objects.create(
        tool_type='HTTP',
        target=url,
        status=status_code,
        output_summary=summary,
        raw_output=raw,
        rtt_ms=14.0 if not is_down else None,
        is_authorized=True,
        triggered_by=triggered_by
    )

    return {
        'success': not is_down,
        'blocked': False,
        'http_code': http_code,
        'summary': summary,
        'raw_output': raw,
        'log_id': log.id
    }

def run_log_analyzer(log_input=None, triggered_by="Technicien IT"):
    """
    Outil Log Analyzer :
    Entrée : Journal de test
    Sortie : Lignes d'erreur et résumé
    """
    if not log_input:
        log_input = """
[10:41:05] [INFO] systemd[1]: Started Apache2 HTTP Server daemon.
[10:42:15] [WARNING] kernel: [EVE-NG] Link veth30_0 down, state changed.
[10:42:19] [ERROR] apache2[2041]: (111)Connection refused: AH00035: service port 80 failed to accept
[10:42:20] [CRITICAL] systemd[1]: apache2.service: Main process exited, code=exited, status=1/FAILURE
[10:43:01] [ERROR] bind9[1105]: error (network unreachable) resolving 'lab.goma.aero'
[10:43:10] [INFO] aeroassist-agent: Scheduled health check triggered.
        """.strip()

    lines = [line.strip() for line in log_input.split('\n') if line.strip()]
    errors = []
    warnings = []
    
    for l in lines:
        if 'ERROR' in l or 'CRITICAL' in l or 'FAILURE' in l or 'refused' in l:
            errors.append(l)
        elif 'WARNING' in l:
            warnings.append(l)

    summary = f"Analyse journal : {len(errors)} erreurs critiques détectées, {len(warnings)} avertissements."
    raw = f"=== RAPPORT D'ANALYSE DE LOGS ===\nTotal lignes analysées : {len(lines)}\nErreurs trouvées ({len(errors)}) :\n" + "\n".join(f"  • {e}" for e in errors)
    if warnings:
        raw += f"\nAvertissements ({len(warnings)}) :\n" + "\n".join(f"  • {w}" for w in warnings)

    log = NetworkDiagnosticLog.objects.create(
        tool_type='LOG',
        target="Journal système EVE-NG",
        status='FAILURE' if errors else 'SUCCESS',
        output_summary=summary,
        raw_output=raw,
        is_authorized=True,
        triggered_by=triggered_by
    )

    return {
        'success': len(errors) == 0,
        'blocked': False,
        'error_count': len(errors),
        'warning_count': len(warnings),
        'summary': summary,
        'errors': errors,
        'warnings': warnings,
        'raw_output': raw,
        'log_id': log.id
    }

def run_assisted_diagnostic(device_ip="192.168.30.10"):
    """
    Orchestrateur de diagnostic assisté par IA (Conforme au cahier des charges p.6 et p.10) :
    1. Ping checker
    2. TCP port 80 checker
    3. DNS checker
    4. HTTP checker
    5. Synthèse & recommandation pour le technicien
    Maximum 5 appels d'outils autorisés.
    """
    device = NetworkDevice.objects.filter(ip_address=device_ip).first()
    device_name = device.name if device else f"Device-{device_ip}"

    # 1. Ping
    ping_res = run_ping_checker(device_ip)
    
    # 2. TCP Port 80
    tcp_res = run_tcp_checker(device_ip, port=80)
    
    # 3. DNS
    dns_res = run_dns_checker("web.lab.goma.aero")
    
    # 4. HTTP
    http_res = run_http_checker(f"http://{device_ip}")

    # Synthèse IA
    ping_status = "OK" if ping_res['success'] else "échec"
    tcp_status = "ouvert" if tcp_res['success'] else "fermé"
    dns_status = "OK" if dns_res['success'] else "échec"
    http_status = "OK" if http_res['success'] else "échec"

    # Détection de cause probable selon le cahier des charges
    if not ping_res['success'] and not tcp_res['success']:
        probable_cause = "Service arrêté ou serveur isolé du réseau. Déconnexion de l'interface ou panne physique/virtuelle du serveur WEB-LAB."
        recommendation = "Vérifier le câble virtuel dans EVE-NG, vérifier l'état de l'interface sur le switch L3 (VLAN 30), et relancer le service Apache/Nginx sur le serveur de test."
        severity = 'critical'
        title = "Serveur WEB-LAB inaccessible (Ping échec, TCP/80 fermé)"
    elif ping_res['success'] and not tcp_res['success']:
        probable_cause = "Le serveur est joignable au niveau IP (couche 3), mais le démon HTTP (Apache2/Nginx) est arrêté ou le port 80 est bloqué par le pare-feu local."
        recommendation = "Se connecter en SSH au serveur WEB-LAB et exécuter 'systemctl status apache2' puis 'systemctl restart apache2'."
        severity = 'warning'
        title = "Service HTTP arrêté sur WEB-LAB"
    elif not dns_res['success']:
        probable_cause = "Erreur de résolution DNS : le serveur DNS-LAB (192.168.30.11) est injoignable ou le service BIND9 ne répond plus."
        recommendation = "Vérifier le démon DNS sur DNS-LAB (service bind9/named), vérifier la configuration de zone /etc/bind/db.lab.goma.aero."
        severity = 'warning'
        title = "Panne de résolution DNS locale"
    else:
        probable_cause = "Tous les indicateurs réseau (Ping, TCP 80, DNS, HTTP) sont nominaux. Aucun incident actif."
        recommendation = "Poursuivre la surveillance automatique de routine. Aucune intervention requise."
        severity = 'info'
        title = f"{device_name} pleinement opérationnel"

    # Enregistrement ou mise à jour de l'incident
    incident = None
    if severity in ['critical', 'warning']:
        incident, _ = NetworkIncident.objects.update_or_create(
            device=device,
            status__in=['open', 'acknowledged'],
            defaults={
                'title': title,
                'severity': severity,
                'status': 'open',
                'ping_result': ping_status,
                'tcp_port': 80,
                'tcp_result': tcp_status,
                'dns_result': dns_status,
                'http_result': http_status,
                'ai_probable_cause': probable_cause,
                'ai_recommendation': recommendation,
            }
        )

    return {
        'device_name': device_name,
        'device_ip': device_ip,
        'ping': ping_res,
        'tcp': tcp_res,
        'dns': dns_res,
        'http': http_res,
        'probable_cause': probable_cause,
        'recommendation': recommendation,
        'severity': severity,
        'incident': incident,
    }

