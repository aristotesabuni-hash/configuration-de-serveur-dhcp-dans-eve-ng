from django.core.management.base import BaseCommand
from django.utils import timezone
from aeroassist.models import (
    ProcedureCategory,
    ProcedureDocument,
    FAQItem,
    NetworkVlan,
    NetworkDevice,
    NetworkIncident,
    NetworkDiagnosticLog,
    SystemSetting
)
from aeroassist.services.scenarios import initialize_scenarios

class Command(BaseCommand):
    help = "Initialise les données de démonstration du laboratoire AeroAssist AI (VLAN, Equipements, Documents, FAQ)"

    def handle(self, *args, **options):
        self.stdout.write(self.style.NOTICE("Initialisation des données de AeroAssist AI..."))

        # 1. Paramètres système & sécurité
        SystemSetting.set_value(
            "whitelist_subnets",
            "192.168.10.0/24,192.168.20.0/24,192.168.30.0/24,192.168.40.0/24,192.168.50.0/24,192.168.60.0/24,127.0.0.1",
            "Sous-réseaux autorisés du laboratoire EVE-NG"
        )
        SystemSetting.set_value("max_diagnostic_tools_per_run", "5", "Nombre maximal d'appels d'outils par diagnostic")
        SystemSetting.set_value("prompt_injection_guard", "true", "Filtrage strict des instructions masquées")

        # 2. VLANs EVE-NG
        vlans_data = [
            {
                'vlan_id': 10,
                'name': 'ADMINISTRATION',
                'subnet': '192.168.10.0/24',
                'gateway': '192.168.10.1',
                'color': '#3B82F6',
                'icon': 'fa-user-shield',
                'description': 'Zone dédiée aux postes de travail administratifs et gestionnaires'
            },
            {
                'vlan_id': 20,
                'name': 'PASSAGERS',
                'subnet': '192.168.20.0/24',
                'gateway': '192.168.20.1',
                'color': '#10B981',
                'icon': 'fa-users',
                'description': 'Bornes et kiosques d’information interactive pour les passagers'
            },
            {
                'vlan_id': 30,
                'name': 'SERVEURS',
                'subnet': '192.168.30.0/24',
                'gateway': '192.168.30.1',
                'color': '#F59E0B',
                'icon': 'fa-server',
                'description': 'Ferme de serveurs fictifs (Portail Web, Résolution DNS, Base FAQ)'
            },
            {
                'vlan_id': 40,
                'name': 'SUPERVISION',
                'subnet': '192.168.40.0/24',
                'gateway': '192.168.40.1',
                'color': '#8B5CF6',
                'icon': 'fa-heart-pulse',
                'description': 'Machine virtuelle de supervision et orchestrateur AeroAssist'
            },
            {
                'vlan_id': 50,
                'name': 'AFFICHAGE',
                'subnet': '192.168.50.0/24',
                'gateway': '192.168.50.1',
                'color': '#06B6D4',
                'icon': 'fa-tv',
                'description': 'Écrans d’information des vols FIDS et affichage dynamique'
            },
            {
                'vlan_id': 60,
                'name': 'INVITE',
                'subnet': '192.168.60.0/24',
                'gateway': '192.168.60.1',
                'color': '#64748B',
                'icon': 'fa-wifi',
                'description': 'Accès Wi-Fi public invité avec isolation des clients'
            },
        ]

        created_vlans = {}
        for v in vlans_data:
            obj, _ = NetworkVlan.objects.update_or_create(
                vlan_id=v['vlan_id'],
                defaults=v
            )
            created_vlans[v['vlan_id']] = obj

        # 3. Équipements Réseau EVE-NG
        devices_data = [
            {
                'name': 'Pare-feu pfSense',
                'hostname': 'PFSENSE-FW',
                'ip_address': '192.168.10.254',
                'vlan': created_vlans[10],
                'device_type': 'firewall',
                'status': 'online',
                'services': 'Filtrage inter-VLAN, NAT, Stateful Inspection',
                'ports_open': '80, 443, 22',
                'latency_ms': 0.8,
                'x_pos': 500,
                'y_pos': 60,
            },
            {
                'name': 'Routeur Switch L3',
                'hostname': 'ROUTER-LAB',
                'ip_address': '192.168.30.1',
                'vlan': created_vlans[30],
                'device_type': 'router',
                'status': 'online',
                'services': 'Passerelles VLAN (SVI), Routage OSPF/Statique',
                'ports_open': '22',
                'latency_ms': 1.1,
                'x_pos': 500,
                'y_pos': 150,
            },
            {
                'name': 'Switch Cœur 802.1Q',
                'hostname': 'SWITCH-LAB',
                'ip_address': '192.168.30.2',
                'vlan': created_vlans[30],
                'device_type': 'switch',
                'status': 'online',
                'services': 'Trunks 802.1Q, Spanning Tree, Port Security',
                'ports_open': '22',
                'latency_ms': 1.3,
                'x_pos': 500,
                'y_pos': 240,
            },
            {
                'name': 'PC Administrateur',
                'hostname': 'PC-ADMIN',
                'ip_address': '192.168.10.10',
                'vlan': created_vlans[10],
                'device_type': 'client',
                'status': 'online',
                'services': 'SSH, RDP Client, Console de gestion',
                'ports_open': '22',
                'latency_ms': 1.9,
                'x_pos': 130,
                'y_pos': 380,
            },
            {
                'name': 'Kiosque Passagers',
                'hostname': 'KIOSK-TEST',
                'ip_address': '192.168.20.20',
                'vlan': created_vlans[20],
                'device_type': 'kiosk',
                'status': 'online',
                'services': 'Interface Web Démo Kiosk Chromium',
                'ports_open': '80, 443',
                'latency_ms': 2.1,
                'x_pos': 280,
                'y_pos': 380,
            },
            {
                'name': 'Serveur Web Apache',
                'hostname': 'WEB-LAB',
                'ip_address': '192.168.30.10',
                'vlan': created_vlans[30],
                'device_type': 'server',
                'status': 'online',
                'services': 'HTTP (80), HTTPS (443), SSH (22)',
                'ports_open': '80, 443, 22',
                'latency_ms': 2.4,
                'x_pos': 440,
                'y_pos': 380,
            },
            {
                'name': 'Serveur DNS BIND9',
                'hostname': 'DNS-LAB',
                'ip_address': '192.168.30.11',
                'vlan': created_vlans[30],
                'device_type': 'server',
                'status': 'online',
                'services': 'DNS UDP/TCP (53), SSH (22)',
                'ports_open': '53, 22',
                'latency_ms': 1.8,
                'x_pos': 590,
                'y_pos': 380,
            },
            {
                'name': 'VM AeroAssist IA',
                'hostname': 'AEROASSIST-VM',
                'ip_address': '192.168.40.10',
                'vlan': created_vlans[40],
                'device_type': 'vm',
                'status': 'online',
                'services': 'Django (8000), Ollama Local (11434), Ping/TCP Checker',
                'ports_open': '8000, 22',
                'latency_ms': 0.5,
                'x_pos': 730,
                'y_pos': 380,
            },
            {
                'name': 'Écran Affichage FIDS',
                'hostname': 'DISPLAY-LAB',
                'ip_address': '192.168.50.10',
                'vlan': created_vlans[50],
                'device_type': 'display',
                'status': 'online',
                'services': 'Client FIDS Affichage Dynamique',
                'ports_open': '80',
                'latency_ms': 2.8,
                'x_pos': 860,
                'y_pos': 380,
            },
            {
                'name': 'Poste Wi-Fi Invité',
                'hostname': 'GUEST-PC',
                'ip_address': '192.168.60.20',
                'vlan': created_vlans[60],
                'device_type': 'client',
                'status': 'online',
                'services': 'Client Navigateur Web',
                'ports_open': '',
                'latency_ms': 3.4,
                'x_pos': 980,
                'y_pos': 380,
            },
        ]

        created_devices = {}
        for d in devices_data:
            obj, _ = NetworkDevice.objects.update_or_create(
                hostname=d['hostname'],
                defaults=d
            )
            created_devices[d['hostname']] = obj

        # 4. Catégories et Documents de procédures
        categories_data = [
            {
                'code': 'preparation',
                'name': '1. Préparer son voyage',
                'icon': 'fa-passport',
                'description': 'Documents requis, visas, pièces d\'identité et formalités sanitaires',
                'display_order': 1
            },
            {
                'code': 'enregistrement',
                'name': '2. Enregistrement',
                'icon': 'fa-ticket',
                'description': 'Comptoirs des compagnies aériennes, heures limites et cartes d\'embarquement',
                'display_order': 2
            },
            {
                'code': 'bagages',
                'name': '3. Bagages en soute & cabine',
                'icon': 'fa-suitcase-rolling',
                'description': 'Poids autorisés, dimensions, articles interdits et étiquetage',
                'display_order': 3
            },
            {
                'code': 'controles',
                'name': '4. Contrôles et sûreté',
                'icon': 'fa-shield-halved',
                'description': 'Contrôle DGM (Immigration), sûreté RVA, douane DGDA et inspection sanitaire',
                'display_order': 4
            },
            {
                'code': 'embarquement',
                'name': '5. Salle d’attente & Embarquement',
                'icon': 'fa-plane-departure',
                'description': 'Portes, annonces sonores, priorité d’embarquement et consignes de piste',
                'display_order': 5
            },
            {
                'code': 'assistance',
                'name': '6. Assistance & Services spéciaux',
                'icon': 'fa-hands-holding-child',
                'description': 'Personnes à mobilité réduite (PMR), enfants voyageant seuls et objets trouvés',
                'display_order': 6
            },
        ]

        created_cats = {}
        for c in categories_data:
            obj, _ = ProcedureCategory.objects.update_or_create(
                code=c['code'],
                defaults=c
            )
            created_cats[c['code']] = obj

        # Documents officiels
        docs_data = [
            {
                'category': created_cats['preparation'],
                'title': 'Guide Officiel des Formalités de Voyage — Aéroport de Goma',
                'source': 'Manuel d\'exploitation RVA — Aéroport International de Goma',
                'version': 'v2.4 (2026)',
                'validator': 'Direction RVA Goma & Direction Générale de Migration (DGM)',
                'summary': 'Procédures documentaires obligatoires : passeport valide 6 mois, visa pour non-résidents, carnet international de vaccination contre la fièvre jaune (OMS).',
                'content': """
Formalités obligatoires pour tout départ ou arrivée à l'Aéroport International de Goma :
1. Passeport ou pièce d'identité : Tout passager international doit présenter un passeport biométrique valide au moins six mois après la date prévue du retour. Pour les vols nationaux (ex: Kinshasa, Lubumbashi, Kisangani), une carte d'électeur ou une pièce d'identité officielle en cours de validité est acceptée.
2. Formalités sanitaires : Le carnet international de vaccination (Carte Jaune) attestant de la vaccination contre la fièvre jaune est obligatoire pour entrer ou quitter le territoire de la République Démocratique du Congo.
3. Billet de voyage : Une réservation confirmée ou un e-billet au nom du passager doit être présentée à l'entrée de l'aérogare.
                """.strip()
            },
            {
                'category': created_cats['enregistrement'],
                'title': 'Procédures d\'Enregistrement et Gestion des Comptoirs',
                'source': 'Régie des Voies Aériennes (RVA) — Département des Opérations Sol',
                'version': 'v3.1 (2026)',
                'validator': 'RVA Goma & CAA (Compagnies Aériennes Agréées)',
                'summary': 'Heures limites d\'enregistrement : 3h avant pour vols internationaux, 2h pour vols nationaux. Fermeture 45 minutes avant décollage.',
                'content': """
Modalités d'enregistrement à l'Aéroport de Goma :
- Heure d'arrivée recommandée : Présentez-vous 3 heures avant l'heure de départ pour les vols internationaux et au moins 2 heures avant pour les vols domestiques.
- Fermeture des comptoirs : Les comptoirs d'enregistrement ferment strictement 45 minutes avant l'heure prévue du vol. Aucun enregistrement n'est possible après ce délai.
- Carte d'accès à bord (Boarding Pass) : Remise au comptoir après pesée des bagages et vérification d'identité. Conservez précieusement ce document jusqu'à la montée dans l'avion.
                """.strip()
            },
            {
                'category': created_cats['bagages'],
                'title': 'Réglementation Bagages et Sûreté Aérienne',
                'source': 'RVA Goma & Organisation de l\'Aviation Civile Internationale (OACI)',
                'version': 'v4.0 (2026)',
                'validator': 'Comité National de Sûreté Aéronautique RDC',
                'summary': 'Limites de poids : 20 à 23 kg en soute selon compagnie, 7 à 10 kg en cabine. Produits liquides limités à 100ml en cabine.',
                'content': """
Consignes relatives aux bagages :
- Bagage en soute : Poids maximal généralement compris entre 20 kg et 23 kg selon la franchise de votre compagnie (Congo Airways, CAA, RwandAir, Ethiopian). L'étiquetage avec nom, prénom et numéro de téléphone est obligatoire.
- Bagage cabine : 1 seul bagage à main (max 7 à 10 kg). Tous les liquides, gels et aérosols doivent être conditionnés dans des flacons de 100 ml maximum, placés dans un sachet transparent fermé.
- Objets strictement interdits : Armes, répliques, feux d'artifice, bouteilles de gaz, objets tranchants ou contondants, substances chimiques ou inflammables.
                """.strip()
            },
            {
                'category': created_cats['controles'],
                'title': 'Parcours des Contrôles de Sécurité et Immigration',
                'source': 'DGM Nord-Kivu & Sûreté RVA Goma',
                'version': 'v2.0 (2026)',
                'validator': 'Direction Générale de Migration (DGM) & DGDA',
                'summary': 'Succession des contrôles : contrôle sanitaire DGS, filtre d’immigration DGM, inspection sûreté RVA avec scanners à rayons X et douane DGDA.',
                'content': """
Ordre de passage des contrôles réglementaires :
1. Contrôle Sanitaire : Vérification du carnet de vaccination fièvre jaune et prise de température par les agents du Programme National de l'Hygiène aux Frontières (PNHF).
2. Contrôle Immigration (DGM) : Contrôle d'authenticité du passeport, visa de sortie/entrée et apposition du cachet de voyage.
3. Filtre de Sûreté (RVA) : Passage sous le portique détecteur de métaux. Déposez dans les bacs : ceinture, montre, monnaie, téléphone et ordinateur portable sorti de sa housse.
4. Contrôle Douanier (DGDA) : Déclaration des devises et marchandises réglementées si applicable.
                """.strip()
            },
            {
                'category': created_cats['embarquement'],
                'title': 'Guide de la Salle d\'Attente et Embarquement',
                'source': 'RVA Goma — Gestion de l\'Aérogare Passagers',
                'version': 'v1.5 (2026)',
                'validator': 'Direction de l\'Aéroport de Goma',
                'summary': 'Accès à la salle d\'embarquement après contrôles. Suivre les annonces sonores et les agents RVA pour l\'acheminement vers l\'aéronef.',
                'content': """
Embarquement et cheminement piste :
- Salle d'attente : Une fois les contrôles franchis, vous accédez à la salle d'attente sécurisée équipée de sièges, de sanitaires et de points de rafraîchissement.
- Annonce d'embarquement : Les agents d'escale appellent les passagers par numéros de rangées ou zones. Présentez votre carte d'embarquement et pièce d'identité.
- Sortie sur piste : Suivez strictement les corridors balisés par les agents de piste RVA. Il est formellement interdit de s'écarter du chemin balisé ou d'utiliser un téléphone portable à proximité des moteurs de l'avion.
                """.strip()
            },
        ]

        for d in docs_data:
            ProcedureDocument.objects.update_or_create(
                title=d['title'],
                defaults=d
            )

        # 5. Base de connaissances FAQ bilingue & swahili
        faqs_data = [
            {
                'category': created_cats['preparation'],
                'question_fr': "Comment se passe mon passage à l'aéroport de Goma ?",
                'answer_fr': "Votre parcours à l'Aéroport International de Goma se déroule en 4 étapes majeures : (1) Préparer vos documents (passeport/pièce d'identité, billet, carnet jaune), (2) Vous enregistrer au comptoir de votre compagnie aérienne et déposer vos bagages de soute, (3) Passer les contrôles sanitaires, d'immigration (DGM) et de sûreté RVA, (4) Rejoindre la salle d'embarquement et suivre les consignes des agents jusqu'à l'avion.",
                'question_en': "How does my journey through Goma airport work?",
                'answer_en': "Your journey through Goma International Airport follows 4 main steps: (1) Prepare your documents (passport/ID, ticket, yellow fever certificate), (2) Check in at your airline counter and drop checked luggage, (3) Go through health, immigration (DGM) and RVA security checkpoints, (4) Wait in the departure lounge and follow staff announcements to board.",
                'question_sw': "Je, safari yangu inapitiaje katika uwanja wa ndege wa Goma?",
                'answer_sw': "Safari yako kwenye Uwanja wa Ndege wa Kimataifa wa Goma inafuata hatua 4 kuu: (1) Kuandaa nyaraka zako (pasipoti/kitambulisho, tiketi, cheti cha chanjo ya homa ya manjano), (2) Kujisajili kwenye dawati la ndege yako na kuacha mzigo mkubwa, (3) Kupita ukaguzi wa afya, uhamiaji (DGM) na usalama wa RVA, (4) Kuingia kwenye ukumbi wa kusubiri na kufuata mwongozo wa wahudumu ili kupanda ndege.",
                'keywords': "parcours, etapes, passage, comment, aeroport, voyage, safari",
                'source_citation': "Manuel d'accueil et des procédures passagers — RVA Goma (v2.4)"
            },
            {
                'category': created_cats['preparation'],
                'question_fr': "Quels sont les documents obligatoires pour voyager depuis Goma ?",
                'answer_fr': "Les documents obligatoires sont : (1) Votre passeport valide au moins 6 mois pour un vol international (ou pièce d'identité officielle pour les vols nationaux en RDC), (2) Votre billet d'avion ou réservation confirmée, (3) Le carnet international de vaccination attestant du vaccin contre la fièvre jaune, (4) Un visa valide d'entrée ou de séjour si requis par le pays de destination.",
                'question_en': "What documents do I need to prepare before traveling through Goma airport?",
                'answer_en': "Mandatory travel documents are: (1) Valid passport (at least 6 months validity for international flights) or national ID for domestic flights, (2) Confirmed airline ticket or boarding pass, (3) Yellow fever international vaccination card (mandatory), (4) Valid entry visa for destination if applicable.",
                'question_sw': "Ni nyaraka gani zinazohitajika kabla ya kusafiri uwanja wa ndege wa Goma?",
                'answer_sw': "Nyaraka za lazima ni: (1) Pasipoti halali kwa angalau miezi 6 kwa safari za kimataifa (au kitambulisho rasmi kwa safari za ndani ya nchi), (2) Tiketi halali ya ndege, (3) Cheti cha kimataifa cha chanjo ya homa ya manjano (ya lazima kabisa), (4) Visa ya kuingia nchi unayoelekea kama inahitajika.",
                'keywords': "documents, passeport, visa, vaccin, fievre jaune, carnet jaune, karatasi, pasipoti",
                'source_citation': "Guide Officiel des Formalités — DGM & RVA Goma"
            },
            {
                'category': created_cats['enregistrement'],
                'question_fr': "Combien de temps avant le vol dois-je arriver pour l'enregistrement ?",
                'answer_fr': "Il est fortement recommandé d'arriver au moins 3 heures avant l'heure prévue pour les vols internationaux et au moins 2 heures avant pour les vols domestiques nationaux. Attention : les comptoirs d'enregistrement ferment rigoureusement 45 minutes avant le décollage.",
                'question_en': "How long before the flight should I arrive for check-in?",
                'answer_en': "You should arrive at least 3 hours before scheduled departure for international flights, and at least 2 hours prior for domestic flights within DR Congo. Note: Check-in counters close strictly 45 minutes before takeoff.",
                'question_sw': "Muda gani kabla ya ndege ninapaswa kufika kwa ajili ya usajili?",
                'answer_sw': "Inashauriwa kufika uwanjani angalau saa 3 kabla ya ndege kuondoka kwa safari za kimataifa, na saa 2 kabla kwa safari za ndani ya nchi. Kumbuka: madawati ya usajili hufungwa kabisa dakika 45 kabla ya ndege kuruka.",
                'keywords': "heure, arrivee, avance, enregistrement, retard, comptoir, saa, wakati",
                'source_citation': "Règlement d'exploitation des aérogares — RVA Goma"
            },
            {
                'category': created_cats['bagages'],
                'question_fr': "Quel est le poids autorisé pour mes bagages en soute et en cabine ?",
                'answer_fr': "La franchise standard autorisée est de 20 à 23 kg pour un bagage en soute et de 7 à 10 kg pour un bagage en cabine (selon les règles spécifiques de votre compagnie aérienne). Les liquides en cabine sont limités à 100 ml par flacon. Tout excédent de poids sera facturé au comptoir selon le tarif de la compagnie.",
                'question_en': "What is the baggage weight allowance for checked and cabin bags?",
                'answer_en': "Standard baggage allowance is 20 to 23 kg for checked luggage and 7 to 10 kg for hand luggage (depending on your specific airline). Liquids in cabin luggage must not exceed 100 ml containers. Excess luggage will incur extra charges at the counter.",
                'question_sw': "Uzito gani wa mzigo unaruhusiwa kwenye ndege?",
                'answer_sw': "Kiwango cha kawaida cha mzigo mkubwa ni kilo 20 hadi 23, na mzigo wa mkononi (ndani ya ndege) ni kilo 7 hadi 10 kutegemea shirika lako la ndege. Vimiminika kwenye mzigo wa mkononi visizidi mililita 100 kwa kila chupa.",
                'keywords': "bagages, poids, kilos, franchise, soute, cabine, mzigo, kilo",
                'source_citation': "Réglementation IATA & Compagnies Aériennes Partenaires RVA Goma"
            },
            {
                'category': created_cats['controles'],
                'question_fr': "Quels sont les contrôles de sécurité à passer avant d'embarquer ?",
                'answer_fr': "Vous passerez par : (1) Le contrôle sanitaire pour la vérification du carnet de vaccination, (2) L'immigration (DGM) pour le contrôle du passeport et cachet, (3) Le poste d'inspection filtrage de sûreté RVA avec passage sous portique détecteur et scanner des bagages à main (veuillez retirer métaux, ceintures et ordinateurs portables).",
                'question_en': "What security checks must I pass before boarding?",
                'answer_en': "You must complete: (1) Health checkpoint (yellow fever verification), (2) Immigration clearance (DGM) for passport stamping, (3) RVA security screening (metal detector walkthrough, X-ray baggage scan; electronics and belts must be placed in trays).",
                'question_sw': "Ni ukaguzi gani wa usalama nitakaopitia kabla ya kuingia kwenye ndege?",
                'answer_sw': "Utapitia ukaguzi wa: (1) Afya (cheti cha chanjo), (2) Uhamiaji (DGM) kwa kugongwa mhuri kwenye pasipoti, (3) Ukaguzi wa usalama wa RVA (kupita kwenye mashine ya kutambua vyuma na skana ya mizigo ya mkononi; toa mikanda na tarakilishi).",
                'keywords': "controles, securite, fouille, dgm, rva, scanner, portique, ukaguzi",
                'source_citation': "Direction de la Sûreté Aéronautique RVA"
            },
            {
                'category': created_cats['assistance'],
                'question_fr': "Existe-t-il une assistance pour les personnes à mobilité réduite ou enfants seuls ?",
                'answer_fr': "Oui, l'Aéroport International de Goma dispose d'un service d'assistance dédié aux passagers à mobilité réduite (fauteuils roulants, accompagnement personnalisé) et aux mineurs non accompagnés (UM). Veuillez signaler votre besoin à votre compagnie lors de la réservation ou vous adresser au guichet d'assistance RVA dans le hall principal dès votre arrivée.",
                'question_en': "Is there assistance for persons with reduced mobility or unaccompanied minors?",
                'answer_en': "Yes, Goma International Airport provides dedicated assistance for passengers with reduced mobility (wheelchairs, escort) and unaccompanied minors (UM). Please notify your airline upon booking or contact the RVA Information Desk upon arrival.",
                'question_sw': "Kuna msaada wowote kwa watu wenye ulemavu au watoto wanaosafiri peke yao?",
                'answer_sw': "Ndiyo, Uwanja wa Ndege wa Goma una huduma maalumu ya kusaidia watu wenye ulemavu (viti vya magurudumu, mwongozo) na watoto wanaosafiri pekee yao. Tafadhali wasiliana na dawati la taarifa la RVA mara tu unapofika.",
                'keywords': "assistance, pmr, fauteuil, enfant seul, mineur, handicap, msaada",
                'source_citation': "Service d'Accueil et Facilitation — RVA Goma"
            },
        ]

        for f in faqs_data:
            FAQItem.objects.update_or_create(
                question_fr=f['question_fr'],
                defaults=f
            )

        # 6. Initialisation d'une alerte témoin pour la maquette initiale (Page 2 & 6)
        web_dev = created_devices.get('WEB-LAB')
        if web_dev:
            # Créer l'incident initial mentionné dans le cahier des charges : "Serveur WEB-LAB : indisponible"
            NetworkIncident.objects.update_or_create(
                device=web_dev,
                title="Service web non joignable (WEB-LAB indisponible)",
                defaults={
                    'severity': 'warning',
                    'status': 'open',
                    'ping_result': 'échec',
                    'tcp_port': 80,
                    'tcp_result': 'fermé',
                    'dns_result': 'OK',
                    'http_result': 'échec (503)',
                    'ai_probable_cause': 'Service arrêté ou serveur isolé. Connexion refusée sur le port 80.',
                    'ai_recommendation': 'Vérifier le service sur le serveur de test. Lancer "systemctl status apache2" et rétablir le port.',
                    'created_at': timezone.now()
                }
            )

        # 7. Initialiser les 10 scénarios de test officiels
        initialize_scenarios()

        self.stdout.write(self.style.SUCCESS("[OK] Donnees AeroAssist AI initialisees avec succes !"))
