from aeroassist.models import NetworkIncident, FAQItem

def global_context(request):
    current_role = request.session.get('user_role', 'technician')
    role_names = {
        'passenger': 'Passager / Visiteur',
        'info_agent': 'Agent d\'information',
        'technician': 'Technicien IT',
        'admin': 'Administrateur',
    }
    
    # Active alerts count
    active_incidents = NetworkIncident.objects.filter(status__in=['open', 'acknowledged'])
    active_alerts_count = active_incidents.count()
    critical_alerts_count = active_incidents.filter(severity='critical').count()
    
    return {
        'current_role': current_role,
        'current_role_name': role_names.get(current_role, 'Technicien IT'),
        'active_alerts_count': active_alerts_count,
        'critical_alerts_count': critical_alerts_count,
        'app_name': 'AeroAssist AI',
        'airport_name': 'Aéroport International de Goma',
        'airport_code': 'GOM / FZNA',
    }

