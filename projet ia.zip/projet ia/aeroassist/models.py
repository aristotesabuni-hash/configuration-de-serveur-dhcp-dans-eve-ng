from django.db import models
from django.utils import timezone
import json

class ProcedureCategory(models.Model):
    code = models.CharField(max_length=50, unique=True)
    name = models.CharField(max_length=150)
    icon = models.CharField(max_length=50, default='fa-plane')
    description = models.TextField(blank=True)
    display_order = models.IntegerField(default=0)

    class Meta:
        ordering = ['display_order', 'name']
        verbose_name = "Catégorie de procédure"
        verbose_name_plural = "Catégories de procédures"

    def __str__(self):
        return self.name


class ProcedureDocument(models.Model):
    category = models.ForeignKey(ProcedureCategory, on_delete=models.CASCADE, related_name='documents')
    title = models.CharField(max_length=255)
    content = models.TextField()
    summary = models.TextField(blank=True)
    source = models.CharField(max_length=255, default="RVA Goma - Manuel d'exploitation")
    version = models.CharField(max_length=50, default="v1.0")
    validator = models.CharField(max_length=255, default="Direction RVA / DGM Goma")
    validation_date = models.DateField(default=timezone.now)
    is_active = models.BooleanField(default=True)
    language = models.CharField(max_length=10, default="fr")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Document de procédure"
        verbose_name_plural = "Documents de procédures"

    def __str__(self):
        return f"{self.title} ({self.version})"


class FAQItem(models.Model):
    category = models.ForeignKey(ProcedureCategory, on_delete=models.CASCADE, related_name='faqs')
    document = models.ForeignKey(ProcedureDocument, on_delete=models.SET_NULL, null=True, blank=True, related_name='faqs')
    question_fr = models.CharField(max_length=300)
    answer_fr = models.TextField()
    question_en = models.CharField(max_length=300, blank=True)
    answer_en = models.TextField(blank=True)
    question_sw = models.CharField(max_length=300, blank=True)
    answer_sw = models.TextField(blank=True)
    keywords = models.CharField(max_length=255, blank=True, help_text="Mots-clés séparés par des virgules")
    source_citation = models.CharField(max_length=255, default="Régie des Voies Aériennes (RVA) - Aéroport de Goma")
    is_verified = models.BooleanField(default=True)
    flagged_for_review = models.BooleanField(default=False)
    review_notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "FAQ / Procédure"
        verbose_name_plural = "FAQs / Procédures"

    def __str__(self):
        return self.question_fr


class NetworkVlan(models.Model):
    vlan_id = models.IntegerField(unique=True)
    name = models.CharField(max_length=100)
    subnet = models.CharField(max_length=50)
    gateway = models.CharField(max_length=50, default="192.168.1.1")
    description = models.TextField(blank=True)
    color = models.CharField(max_length=20, default="#0284C7")
    icon = models.CharField(max_length=50, default="fa-network-wired")

    class Meta:
        ordering = ['vlan_id']
        verbose_name = "VLAN Réseau"
        verbose_name_plural = "VLANs Réseau"

    def __str__(self):
        return f"VLAN {self.vlan_id} — {self.name} ({self.subnet})"


class NetworkDevice(models.Model):
    DEVICE_TYPES = [
        ('router', 'Routeur L3'),
        ('switch', 'Switch Cœur L2'),
        ('firewall', 'Pare-feu pfSense'),
        ('server', 'Serveur Linux'),
        ('kiosk', 'Kiosque Passager'),
        ('vm', 'Machine Virtuelle Supervision'),
        ('display', 'Écran Affichage FIDS'),
        ('client', 'Client / Poste de Travail'),
    ]

    STATUS_CHOICES = [
        ('online', 'En Ligne'),
        ('warning', 'Alerte / Dégradé'),
        ('offline', 'Hors Ligne / Indisponible'),
    ]

    name = models.CharField(max_length=100)
    hostname = models.CharField(max_length=100)
    ip_address = models.GenericIPAddressField()
    vlan = models.ForeignKey(NetworkVlan, on_delete=models.CASCADE, related_name='devices')
    device_type = models.CharField(max_length=30, choices=DEVICE_TYPES, default='server')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='online')
    services = models.CharField(max_length=200, default="ICMP, SSH")
    ports_open = models.CharField(max_length=100, default="22", help_text="Liste des ports ouverts séparés par des virgules (ex: 80, 53, 22)")
    latency_ms = models.FloatField(default=1.5)
    packet_loss_percent = models.FloatField(default=0.0)
    last_checked = models.DateTimeField(default=timezone.now)
    is_simulated_down = models.BooleanField(default=False)
    service_status_override = models.TextField(default="{}", help_text="Configuration JSON de simulation de pannes")
    x_pos = models.IntegerField(default=100, help_text="Position X dans le schéma EVE-NG")
    y_pos = models.IntegerField(default=100, help_text="Position Y dans le schéma EVE-NG")

    class Meta:
        ordering = ['vlan__vlan_id', 'ip_address']
        verbose_name = "Équipement Réseau EVE-NG"
        verbose_name_plural = "Équipements Réseau EVE-NG"

    def __str__(self):
        return f"{self.name} ({self.ip_address})"

    def get_service_override_dict(self):
        try:
            return json.loads(self.service_status_override)
        except Exception:
            return {}


class NetworkIncident(models.Model):
    SEVERITY_CHOICES = [
        ('critical', 'Critique'),
        ('warning', 'Avertissement'),
        ('info', 'Information'),
    ]

    STATUS_CHOICES = [
        ('open', 'Actif / Non résolu'),
        ('acknowledged', 'Pris en charge'),
        ('resolved', 'Clôturé / Rétabli'),
    ]

    device = models.ForeignKey(NetworkDevice, on_delete=models.CASCADE, related_name='incidents')
    title = models.CharField(max_length=255)
    incident_type = models.CharField(max_length=100, default="service_down")
    severity = models.CharField(max_length=20, choices=SEVERITY_CHOICES, default='warning')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='open')
    ping_result = models.CharField(max_length=50, default="OK")
    tcp_port = models.IntegerField(null=True, blank=True)
    tcp_result = models.CharField(max_length=50, default="OK")
    dns_result = models.CharField(max_length=50, default="OK")
    http_result = models.CharField(max_length=50, default="OK")
    ai_probable_cause = models.TextField()
    ai_recommendation = models.TextField()
    technician_notes = models.TextField(blank=True)
    acknowledged_by = models.CharField(max_length=100, blank=True)
    created_at = models.DateTimeField(default=timezone.now)
    resolved_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = "Incident / Alerte Réseau"
        verbose_name_plural = "Incidents / Alertes Réseau"

    def __str__(self):
        return f"[{self.severity.upper()}] {self.device.name} - {self.title}"


class NetworkDiagnosticLog(models.Model):
    TOOL_CHOICES = [
        ('PING', 'Ping Checker'),
        ('TCP', 'TCP Checker'),
        ('DNS', 'DNS Checker'),
        ('HTTP', 'HTTP Checker'),
        ('LOG', 'Log Analyzer'),
        ('RAG', 'Document Search'),
    ]

    STATUS_CHOICES = [
        ('SUCCESS', 'Succès (OK)'),
        ('FAILURE', 'Échec / Alerte'),
        ('BLOCKED', 'Bloqué (Non autorisé)'),
    ]

    tool_type = models.CharField(max_length=20, choices=TOOL_CHOICES)
    target = models.CharField(max_length=255)
    port = models.IntegerField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES)
    output_summary = models.TextField()
    raw_output = models.TextField(blank=True)
    rtt_ms = models.FloatField(null=True, blank=True)
    is_authorized = models.BooleanField(default=True)
    triggered_by = models.CharField(max_length=100, default="Technicien IT")
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ['-created_at']
        verbose_name = "Journal de Diagnostic"
        verbose_name_plural = "Journaux de Diagnostics"

    def __str__(self):
        return f"{self.created_at.strftime('%H:%M:%S')} {self.tool_type} -> {self.target} [{self.status}]"


class ChatMessage(models.Model):
    ROLE_CHOICES = [
        ('passenger', 'Passager / Visiteur'),
        ('info_agent', 'Agent d\'information'),
        ('technician', 'Technicien IT'),
        ('admin', 'Administrateur'),
    ]

    session_id = models.CharField(max_length=100, default="default-session")
    user_role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='passenger')
    language = models.CharField(max_length=10, default='fr')
    user_text = models.TextField()
    bot_response = models.TextField()
    source_citation = models.TextField(blank=True)
    is_out_of_scope = models.BooleanField(default=False)
    is_injection_attempt = models.BooleanField(default=False)
    prompt_tokens = models.IntegerField(default=0)
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ['created_at']
        verbose_name = "Message de Chat"
        verbose_name_plural = "Messages de Chat"

    def __str__(self):
        return f"Chat [{self.language}] {self.user_text[:40]}..."


class ScenarioRun(models.Model):
    scenario_number = models.IntegerField(unique=True)
    title = models.CharField(max_length=255)
    description = models.TextField()
    input_data = models.TextField()
    expected_output = models.TextField()
    actual_output = models.TextField(blank=True)
    passed = models.BooleanField(default=False)
    diagnostic_details = models.TextField(blank=True)
    last_run_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ['scenario_number']
        verbose_name = "Scénario de Test"
        verbose_name_plural = "Scénarios de Test"

    def __str__(self):
        return f"Scénario {self.scenario_number} : {self.title}"


class SystemSetting(models.Model):
    key = models.CharField(max_length=100, unique=True)
    value = models.TextField()
    description = models.TextField(blank=True)

    @classmethod
    def get_value(cls, key, default=""):
        try:
            return cls.objects.get(key=key).value
        except cls.DoesNotExist:
            return default

    @classmethod
    def set_value(cls, key, value, description=""):
        obj, _ = cls.objects.get_or_create(key=key, defaults={'description': description})
        obj.value = str(value)
        if description:
            obj.description = description
        obj.save()

    def __str__(self):
        return f"{self.key}: {self.value}"
