import requests
import json

pub = "MP-LIVEPK-$sjz99Bwxmv75E/8FySI921pN.R27SJHiNiSJ$$2YHnSw6qWY$v$y$.R/u/7IsofeThUNcW1EF1g3Cic1y7z0AYUyKI1BQaqcuTxSislTSYYYRdO/0vMWY8d"
sec = "MP-LIVESK-o5vOcEdPlrdLwCD75LMy6Tuqz$m2MOGKj9J$0tBvYG2nXNGkU9ORX$Tmzqu4St/SAqUWSCZ2MnAnUk$Ra7cHw.nkavlsXWjO3o.$y$yh07mUkC1oy1qh7pB1"

# Let's test transaction check endpoint or options
url = "https://marchand.maishapay.online/api/transaction/rest/v2/check"
payload = {
    "gatewayMode": 1,
    "publicApiKey": pub,
    "secretApiKey": sec,
    "transactionId": "TEST_PROBE_1"
}

try:
    r = requests.post(url, json=payload, headers={"Content-Type": "application/json"}, timeout=10)
    print("Check status:", r.status_code)
    print("Response:", r.text)
except Exception as e:
    print("Error:", e)
