import requests
import json
import time

pub = "MP-LIVEPK-$sjz99Bwxmv75E/8FySI921pN.R27SJHiNiSJ$$2YHnSw6qWY$v$y$.R/u/7IsofeThUNcW1EF1g3Cic1y7z0AYUyKI1BQaqcuTxSislTSYYYRdO/0vMWY8d"
sec = "MP-LIVESK-o5vOcEdPlrdLwCD75LMy6Tuqz$m2MOGKj9J$0tBvYG2nXNGkU9ORX$Tmzqu4St/SAqUWSCZ2MnAnUk$Ra7cHw.nkavlsXWjO3o.$y$yh07mUkC1oy1qh7pB1"

# Test mobile money structure with dummy test values
url = "https://marchand.maishapay.online/api/collect/v2/store/mobileMoney"
payload = {
    "transactionReference": f"TEST_{int(time.time())}",
    "gatewayMode": "1",
    "publicApiKey": pub,
    "secretApiKey": sec,
    "order": {
        "amount": "1",
        "currency": "USD",
        "customerFullName": "Test Client",
        "customerEmailAdress": "test@goma.aero"
    },
    "paymentChannel": {
        "channel": "MOBILEMONEY",
        "provider": "AIRTEL",
        "walletID": "+243990000000",
        "callbackUrl": "https://example.com/callback"
    }
}

try:
    r = requests.post(url, json=payload, headers={"Content-Type": "application/json"}, timeout=15)
    print("Mobile Money Response Status:", r.status_code)
    print("Response text:", r.text[:1000])
except Exception as e:
    print("Error:", e)
