# ✈️ AeroAssist AI — Aéroport International de Goma
> **Cahier des charges fonctionnel et technique**  
> Assistant des passagers + Supervision informatique simulée avec EVE-NG  
> *Projet académique mixte : SI-Réseaux et Génie Logiciel (Licence 3)*

---

## 🌟 Présentation du Projet

**AeroAssist AI** est une application web conçue en **Python & Django 5.2** répondant intégralement au cahier des charges académique pour le cadre d'étude de l'Aéroport International de Goma (RDC). Elle rassemble en une interface unifiée :

1. **Module Passagers (Génie Logiciel & IA) :**
   - **Assistant conversationnel intelligent** basé sur une base documentaire validée (RVA, DGM, OMS, OACI).
   - **Support multilingue :** Français (par défaut), Anglais et Kiswahili (Swahili).
   - **Garde-fous stricts anti-hallucination :** L'agent n'invente jamais d'horaires de vol, de portes d'embarquement ou de statuts en temps réel, et renvoie systématiquement vers les écrans FIDS et le personnel officiel.
   - **Sécurisation des invites (Prompt Injection Guard) :** Toute consigne masquée ou tentative de manipulation est traitée comme une donnée non fiable et rejetée.
   - **Parcours en 4 étapes :** 1. Préparer, 2. Enregistrement, 3. Contrôles, 4. Embarquement.
   - **Base FAQ & Procédures :** Avec versionnage, dates de validation, et organismes validateurs.

2. **Module Supervision Informatique (SI-Réseaux & EVE-NG) :**
   - **Topologie EVE-NG complète (6 VLANs 802.1Q) :**
     - `VLAN 10 — ADMIN` (192.168.10.0/24, PC-ADMIN .10)
     - `VLAN 20 — PASSAGERS` (192.168.20.0/24, KIOSK-TEST .20)
     - `VLAN 30 — SERVEURS` (192.168.30.0/24, WEB-LAB .10, DNS-LAB .11)
     - `VLAN 40 — SUPERVISION` (192.168.40.0/24, VM AEROASSIST .10)
     - `VLAN 50 — AFFICHAGE` (192.168.50.0/24, DISPLAY-LAB .10)
     - `VLAN 60 — INVITÉ` (192.168.60.0/24, GUEST-PC .20)
     - Pare-feu pfSense, Routeur Switch L3 (Passerelles .1), Switch Cœur 802.1Q.
   - **Schéma réseau vectoriel interactif SVG** avec flux de paquets animés et indicateurs d'état en temps réel.
   - **Sondes de diagnostic :** Ping Checker, TCP Checker (Port 80), DNS Checker, HTTP Checker, Log Analyzer.
   - **Contrôle strict de sécurité :** Seules les adresses IP du laboratoire sont autorisées (les requêtes vers 8.8.8.8 sont immédiatement bloquées).
   - **Simulateur d'incidents :** Permet de couper en direct le serveur WEB-LAB ou DNS-LAB pour la démonstration de soutenance.
   - **Diagnostic assisté par IA :** Analyse automatique des 4 sondes, détermination de la cause probable, recommandation pour le technicien, et principe impératif : *aucune modification réseau automatique sans validation humaine*.
   - **Rapports & Export CSV :** Historique horodaté filtrable et téléchargeable.
   - **Banc de Test des 10 Scénarios :** Interface interactive pour exécuter et prouver la validation des 10 scénarios de la page 10 du cahier des charges.

---

## 🚀 Démarrage Rapide

### 1. Prérequis
- Python 3.10 ou supérieur
- Django 5.x

### 2. Démarrer le serveur de développement
Depuis la racine du projet (`d:\PROJECT\projet ia\`) :

```powershell
python manage.py runserver
```

L'application sera accessible sur : **http://127.0.0.1:8000/**

### 3. Identifiants d'Administration Django
- **URL :** `http://127.0.0.1:8000/admin/`
- **Nom d'utilisateur :** `admin`
- **Mot de passe :** `admin1234`

---

## 🧭 Plan du Site & Fonctionnalités

| URL | Titre & Description | Réf. Maquette |
| :--- | :--- | :--- |
| `/` | **Tableau de bord :** Vue d'ensemble, métriques clés, alertes actives, équipements EVE-NG. | Maquette 4.1 |
| `/assistant/` | **Assistant Passagers :** Chat interactif avec synthèse vocale, RAG et sélection de langue (FR/EN/SW). | Maquette 4.2 |
| `/travel-steps/` | **Étapes du Voyage :** Parcours séquentiel illustré (Préparer, Enregistrement, Contrôles, Embarquement). | Maquette 4.3 |
| `/faq/` | **Base Documentaire & FAQ :** Procédures avec métadonnées officielles (titre, source, version, date). | Maquette 4.4 |
| `/supervision/` | **Supervision IT & EVE-NG :** Topologie SVG interactive, console terminale, sondes Ping/TCP/DNS/HTTP. | Maquette 4.5 & p.8 |
| `/alerts/<id>/` | **Fiche Alerte :** Diagnostic assisté par IA, cause probable, recommandation et boutons technicien. | Maquette 4.6 |
| `/reports/` | **Rapports :** Historique horodaté des tests avec filtres. | Maquette 4.7 |
| `/reports/export/csv/` | **Export CSV :** Téléchargement instantané du journal au format tableur Excel. | Maquette 4.7 |
| `/scenarios/` | **Banc des 10 Scénarios :** Lanceur interactif validant les 10 scénarios officiels. | Page 10 |
| `/settings/` | **Paramètres & Sécurité :** Gestion des rôles, documents, liste blanche IP et LLM local. | Maquette 4.8 |

---

## 🧪 Les 10 Scénarios Officiels du Cahier des Charges

Le banc d'essai accessible sur `/scenarios/` permet d'exécuter et valider en direct :

1. **Question générale sur le parcours :** Réponse claire expliquant les 4 étapes principales à l'aéroport de Goma.
2. **Question en anglais :** Réponse précise formulée en anglais avec les documents requis.
3. **Question sur une porte / horaire :** Respect strict de la règle : l'agent n'invente rien et renvoie vers les écrans FIDS.
4. **Question hors sujet :** Refus poli et recentrage sur les formalités aéroportuaires.
5. **Question imprécise :** Demande courtoise de précision adressée au voyageur.
6. **Serveur web de lab en ligne :** Diagnostic nominal (Ping OK, TCP 80 Ouvert, HTTP 200).
7. **Serveur web arrêté :** Détection de l'arrêt, alerte générée et recommandation IA.
8. **DNS incorrect :** Signalement clair de l'échec de résolution de nom.
9. **IP hors liste blanche (ex: 8.8.8.8) :** Outil bloqué immédiatement par la sécurité.
10. **Document avec consigne cachée / injection :** Rejet sécurisé comme donnée non fiable sans altération des règles.

Pour exécuter la suite de tests automatisée en ligne de commande :
```powershell
python manage.py test
```

---

## 🤖 Intégration de l'API OpenRouter (LLM Cloud)

L'application intègre nativement la passerelle **OpenRouter** pour propulser l'assistant passager avec les modèles de pointe du marché (Llama 3.1, Claude 3.5, Gemini 2.0, DeepSeek R1, GPT-4o, Mistral) :

1. Rendez-vous dans l'onglet **Paramètres & Sécurité** (`/settings/`).
2. Dans le bloc **Passerelle LLM OpenRouter API** :
   - Cochez **Activer OpenRouter**.
   - Collez votre clé d'API (format `sk-or-v1-...`).
   - Sélectionnez un modèle gratuit ou payant (ex. `baidu/ernie-5.5-flash-preview:free`, `google/gemma-4-31b-it:free`, `nvidia/nemotron-3.5-super-vl:free`).
   - Cliquez sur **Tester la connexion API** pour valider la communication en direct.
   - Cliquez sur **Enregistrer les paramètres**.
3. **Fonctionnement Hybride & Résilience :**
   - Lorsque OpenRouter est activé, l'assistant synthétise ses réponses en utilisant le modèle sélectionné combiné aux procédures validées de la RVA Goma (RAG).
   - Les règles de sécurité prioritaires (anti-hallucination d'horaires et anti-injection) restent **toujours actives**.
   - Si la connexion Internet est coupée ou en cas de quota dépassé, le système bascule automatiquement et de manière transparente sur la base locale pour garantir la continuité de service.

---

## 👥 Rôles Utilisateurs

Un sélecteur situé dans la barre de navigation supérieure permet de basculer instantanément de profil lors d'une soutenance :
- **Passager / Visiteur :** Accès au chat d'orientation et aux guides publics.
- **Agent d'information :** Possibilité de consulter et signaler une réponse à corriger.
- **Technicien IT :** Accès complet aux outils de supervision, à la topologie EVE-NG et aux actions sur les alertes.
- **Administrateur :** Gestion des politiques de sécurité et documents.

---
*Projet développé pour l'évaluation Licence 3 SI-Réseaux & Génie Logiciel.*

